# Banking_Management_System
Requirements definition and management is recognized as a necessary step in the delivery of successful system s and software projects, discipline is also required by standards, regulations, and quality improvement initiatives. ... The “BANK MANAGEMENT SYSTEM” undertaken as a project is based on relevant technologies
